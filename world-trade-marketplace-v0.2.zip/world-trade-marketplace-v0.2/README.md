# World Trade Marketplace — Prototype v0.2

A responsive, browser-only B2B marketplace concept focused first on agricultural trade.

## Features in this demo
- Responsive layout for mobile and desktop
- Product search, category/country filters, and sorting
- Save/favorite products using browser local storage
- Demo supplier inquiry form with copyable inquiry preview
- Demo buyer request form
- Add a temporary sample listing in the current browser session
- Clear disclosure that sample offers are not verified
- No build tools or external libraries required

## Run
Open `index.html` in a modern browser, or publish the repository with GitHub Pages.

## Important limitations
This is a front-end prototype, not a production marketplace. Product listings are illustrative. There is no authentication, backend database, shared listing persistence, server-side messaging, email delivery, supplier verification, moderation dashboard, payments, shipping integration, or transaction protection. Demo form data is not sent to a server. Do not enter confidential or sensitive information.

## Before public launch
1. Add secure business accounts and role-based access.
2. Add a database, server-side validation, row-level security, and protected image storage.
3. Build real inquiry delivery with spam controls and rate limits.
4. Implement moderation, reporting, business verification, and audit logs.
5. Add privacy policy, terms, cookie/analytics disclosures if needed, and a process for data deletion.
6. Review sanctions, export/import restrictions, food safety, customs, tax, and advertising obligations for the markets served.
7. Test accessibility, mobile layouts, backups, and security.

## Roadmap
- v0.1: static product discovery page
- v0.2: richer product catalogue, filters, favorites, and demo forms
- v0.3: authenticated profiles and persistent listings
- v0.4: secure inquiry workflow and moderation
- v1.0: production readiness after security, legal, and user testing
